# To establish connection to your kubeflow cluster

## Run following command in your cloud shell terminal

**./conn.sh**
