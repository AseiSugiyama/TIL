directory to cache k8s spec by versions:
v1.11.7
