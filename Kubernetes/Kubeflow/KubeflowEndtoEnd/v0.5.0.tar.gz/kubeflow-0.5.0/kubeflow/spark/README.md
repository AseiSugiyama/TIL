A very early attempt at allowing Apache Spark to be used with Kubeflow.
Starts a container to run the driver program in, and the rest is up to the Spark on K8s integration.
Based on https://github.com/GoogleCloudPlatform/spark-on-k8s-operator
