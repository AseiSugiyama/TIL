// Entrypoint for Webpack
import '@babel/polyfill';

import './assets/kf-logo_64px.svg';
import './styles.css';
import './components/main-page.js';
